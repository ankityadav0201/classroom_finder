/*
 * ClassRoom Finder - FoCP CSE-1003 companion program
 * Demonstrates arrays, structures, functions, loops and selection.
 * The website is the deployable interface; this C program demonstrates
 * the core room-search and availability logic for the FoCP assessment.
 */
#include <stdio.h>
#include <string.h>

#define MAX_ROOMS 20

typedef struct {
    int id;
    char name[30];
    char building[40];
    int capacity;
    int status; /* 0 = Unknown, 1 = Available, 2 = Occupied, 3 = Reserved */
} Room;

void displayRooms(Room rooms[], int count) {
    int i;
    printf("\n%-6s %-20s %-22s %-10s %-12s\n",
           "ID", "ROOM", "BUILDING", "SEATS", "STATUS");
    for (i = 0; i < count; i++) {
        const char *status[] = {"Unknown", "Available", "Occupied", "Reserved"};
        printf("%-6d %-20s %-22s %-10d %-12s\n",
               rooms[i].id, rooms[i].name, rooms[i].building,
               rooms[i].capacity, status[rooms[i].status]);
    }
}

void searchRoom(Room rooms[], int count) {
    char query[30];
    int i, found = 0;
    printf("Enter room name/number: ");
    scanf(" %29[^\n]", query);
    for (i = 0; i < count; i++) {
        if (strcmp(rooms[i].name, query) == 0) {
            printf("Found: %s | %s | Capacity: %d | Status code: %d\n",
                   rooms[i].name, rooms[i].building,
                   rooms[i].capacity, rooms[i].status);
            found = 1;
        }
    }
    if (!found) printf("No matching room found.\n");
}

void showAvailable(Room rooms[], int count) {
    int i, found = 0;
    printf("\nAvailable rooms:\n");
    for (i = 0; i < count; i++) {
        if (rooms[i].status == 1) {
            printf("%s (%s), capacity: %d\n",
                   rooms[i].name, rooms[i].building, rooms[i].capacity);
            found = 1;
        }
    }
    if (!found) printf("No room is currently marked available.\n");
}

int main(void) {
    Room rooms[] = {
        {102, "Room 102", "New Teaching Block", 0, 0},
        {103, "Room 103", "New Teaching Block", 0, 0},
        {108, "NTB-TC-108(B)", "New Teaching Block", 0, 0},
        {206, "NTB-TC-206", "New Teaching Block", 0, 0},
        {208, "NTB-TD-208(B)", "New Teaching Block", 0, 0}
    };
    int count = sizeof(rooms) / sizeof(rooms[0]);
    int choice;
    do {
        printf("\n===== CLASSROOM FINDER =====\n");
        printf("1. Display all room records\n");
        printf("2. Search a room\n");
        printf("3. Show available rooms\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        if (scanf("%d", &choice) != 1) return 0;
        switch (choice) {
            case 1: displayRooms(rooms, count); break;
            case 2: searchRoom(rooms, count); break;
            case 3: showAvailable(rooms, count); break;
            case 4: printf("Thank you.\n"); break;
            default: printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);
    return 0;
}
