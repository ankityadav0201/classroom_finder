# FoCP Project Report — ClassRoom Finder

**Course:** FoCP (CSE-1003)  
**Project type:** Software  
**Project title:** ClassRoom Finder — IIIT Bhopal

## 1. Problem
Students may need a suitable classroom for group study, project discussions or academic meetings. Finding an available room can take time when room schedules and availability are not easy to check.

## 2. Proposed solution
ClassRoom Finder is a responsive web prototype that presents a directory of classroom references. Students can search and filter rooms. An administrator can add or edit room records, update status and add notes about verified schedules.

## 3. Main modules
- Student dashboard
- Room search and filters
- Room information cards
- Admin login (demo only)
- Add, edit and delete room records
- Local browser data storage

## 4. Technologies
HTML, CSS and JavaScript are used for the deployed web interface. A companion C program demonstrates the core data-handling logic using structures, arrays, functions, loops and switch-case.

## 5. Data and limitations
The official IIIT Bhopal annual report describes academic activity primarily in the New Teaching Block and MPSTEP Building and reports 24 classrooms among institute facilities. Some room references are present in a 2025 official first-semester timetable. Since that timetable is historical, the project does not assume that those room assignments are current. All initial room statuses are marked Unknown. Current room allocation, seating capacity and timetable details must be confirmed with authorized campus sources.

The prototype does not connect to an official timetable, sensors or a shared database. Changes are saved only in the current browser. The admin password is for demonstration and is not secure authentication.

## 6. Future scope
- Connect an authorized current timetable data source.
- Add a secure shared database and authentication.
- Add time-slot conflict checking.
- Add verified room capacity and accessibility details.
- Add a feedback/reporting option.

## 7. Conclusion
ClassRoom Finder demonstrates how a small software system can address a campus information problem. It provides a working search interface and an admin-editable room directory while clearly identifying information that still needs official verification.
